import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetDataService {
  
  ID : number;

  
  private url = "http://localhost:9000/student";
  
  constructor(private httpClient: HttpClient) { }
  
  getPosts(){
   
    return this.httpClient.get(this.url);
    
  }

  getById(id:number){
    this.ID = id;
   
   return this.httpClient.get("http://localhost:9000/student/"+id);

  }

  getAllteacher(){
    return this.httpClient.get("http://localhost:9000/teacher/");
  }

  getCurrentId(){
    
    return this.ID;
  }

}
