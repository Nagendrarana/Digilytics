import { Component, OnInit } from '@angular/core';
import { GetDataService } from 'src/app/service/get-data.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  current_id :number;
  posts:any;

  constructor(private service :GetDataService) { }

  ngOnInit(): void {
    this.current_id= this.service.getCurrentId();
    this.service.getById(this.current_id).subscribe(response => {
      this.posts = response;
      });
  }

  

}
