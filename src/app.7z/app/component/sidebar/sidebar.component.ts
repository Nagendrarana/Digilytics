import { Component, OnInit } from '@angular/core';
import {GetDataService} from '../../service/get-data.service'


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  posts:any;
  current_id : number;
  img_url :String ;

  fees_button=false;
  attendence_button=true;
  result_button=false;
  home_button=false;
  constructor(private service:GetDataService) { 
  
  }

  ngOnInit(): void {
    this.current_id=this.service.getCurrentId();
    
    this.service.getById(this.current_id)
    .subscribe(response => {
      this.posts = response;
      
    });
  }

  fee(){
    this.fees_button=true;
    this.attendence_button=false;
    this.result_button=false;
    this.home_button=false;
  }
  result(){
    this.fees_button=false;
    this.attendence_button=false;
    this.result_button=true; 
    this.home_button=false;

   }
  attendence(){
    this.fees_button=false;
    this.attendence_button=true;
    this.result_button=false; 
    this.home_button=false;

   }
   home(){
    this.fees_button=false;
    this.attendence_button=false;
    this.result_button=false; 
    this.home_button=true;
   }

}
