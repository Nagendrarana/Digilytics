import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {
 
  student_data=false;
  attendence=false;
  chart=true;
  constructor() { }

  ngOnInit(): void {
   

  }
  view(){
     
      this.student_data=true;
      this.attendence=false;
      this.chart=false;
  }
 attend(){
  this.attendence=true;
  this.chart=false;
  this.student_data=false;

 }
 view_result(){
  
  this.chart = true;
  this.attendence=false;
  this.student_data=false;
 }

}
